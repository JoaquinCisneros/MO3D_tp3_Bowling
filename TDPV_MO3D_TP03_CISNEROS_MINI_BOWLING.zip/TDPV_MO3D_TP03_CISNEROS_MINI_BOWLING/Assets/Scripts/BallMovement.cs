using UnityEngine;

public class BallMovement : MonoBehaviour
{
    public float lateralSpeed = 5f;
    public float minZ = -5f;
    public float maxZ = 5f;

    public float maxLaunchForce = 1000f;
    public float chargeRate = 200f;

    private float currentLaunchForce = 0f;
    private bool isLaunched = false;
    private Rigidbody rb;

    public Transform forceBarContainer;
    public Transform forceBarFill;

    private Vector3 initialScale;

    public float fallThreshold = -5f; // Limite de caida

    // Referencia al SceneReset (que actuaria como GameManager)
    private SceneReset sceneReset;

    void Start()
    {
        rb = GetComponent<Rigidbody>();

        if (forceBarFill != null)
        {
            initialScale = forceBarFill.localScale;
        }

        // Obtener la referencia al SceneReset (GameManager)
        sceneReset = FindObjectOfType<SceneReset>();
    }

    void Update()
    {
        if (!isLaunched)
        {
            float horizontal = Input.GetAxis("Horizontal");
            Vector3 movement = new Vector3(0, 0, horizontal * lateralSpeed * Time.deltaTime);
            transform.Translate(movement);

            // Limitar movimiento horizontal de la bola
            Vector3 clampedPosition = transform.position;
            clampedPosition.z = Mathf.Clamp(clampedPosition.z, minZ, maxZ);
            transform.position = clampedPosition;

            if (Input.GetKey(KeyCode.Space))
            {
                ChargeForce();
            }

            if (Input.GetKeyUp(KeyCode.Space))
            {
                LaunchBall();
            }

            UpdateForceBar();
        }

        // Si cayo la bola
        if (transform.position.y < fallThreshold)
        {
            // Reiniciar a traves del gameManager
            sceneReset.RestartScene();
        }
    }

    void ChargeForce()
    {
        currentLaunchForce += chargeRate * Time.deltaTime;
        currentLaunchForce = Mathf.Clamp(currentLaunchForce, 0, maxLaunchForce);
    }

    void LaunchBall()
    {
        rb.AddForce(Vector3.right * currentLaunchForce);
        isLaunched = true;
        currentLaunchForce = 0f;
        UpdateForceBar();
    }

    void UpdateForceBar()
    {
        if (forceBarFill != null)
        {
            float forceRatio = currentLaunchForce / maxLaunchForce;
            forceBarFill.localScale = new Vector3(initialScale.x, initialScale.y * forceRatio, initialScale.z);
        }
    }
}



